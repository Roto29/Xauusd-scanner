# XAUUSD Scanner — phone-only APK build

This project is prepared for a cloud build with GitHub Actions.

## On your Android phone
1. Create/sign in to a GitHub account.
2. Create a new repository.
3. Upload the contents of this project ZIP to the repository (not the ZIP itself).
4. Open the repository's **Actions** tab.
5. Choose **Build XAUUSD Scanner APK** and run the workflow.
6. When it finishes, open the workflow run and download the **XAUUSD-Scanner-debug** artifact.
7. Extract the artifact and install `app-debug.apk` on your Android phone.

The current app contains the scanner prototype and simulated market data. Live XAUUSD data still needs a licensed data/broker API.
